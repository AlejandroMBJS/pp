/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Upload, 
  CheckCircle2, 
  XCircle, 
  Loader2, 
  Image as ImageIcon, 
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  History,
  Download,
  Trash2,
  Maximize2,
  Layers
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// --- Types ---

interface AnalysisResult {
  id: string;
  timestamp: number;
  render: string;
  avance: string;
  analisis_visual: string;
  elementos_ignorados: string;
  calificacion_porcentaje: number;
  aprobado: boolean;
}

// --- App Component ---

export default function App() {
  const [renderImage, setRenderImage] = useState<string | null>(null);
  const [avanceImage, setAvanceImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [sliderPos, setSliderPos] = useState(50);
  const [showComparison, setShowComparison] = useState(false);
  
  // Estados de transformación totalmente independientes
  const [renderTransform, setRenderTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [avanceTransform, setAvanceTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [activeLayer, setActiveLayer] = useState<'both' | 'render' | 'avance'>('both');
  
  const [isPanning, setIsPanning] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [isDraggingSlider, setIsDraggingSlider] = useState(false);

  const renderInputRef = useRef<HTMLInputElement>(null);
  const avanceInputRef = useRef<HTMLInputElement>(null);
  const comparisonRef = useRef<HTMLDivElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'render' | 'avance') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError("Por favor sube un archivo de imagen válido.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (type === 'render') setRenderImage(result);
      else setAvanceImage(result);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const analyzeProgress = async () => {
    if (!renderImage || !avanceImage) {
      setError("Por favor sube ambas imágenes para comenzar.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      
      const prompt = `Actúa como un Inspector de Calidad Experto en arquitectura, mecanizado y modelado 3D. Tu tarea es comparar dos imágenes y evaluar objetivamente el progreso de un proyecto.

Se te proporcionarán dos imágenes:
1. "Render": El diseño final y objetivo del proyecto.
2. "Avance": Una fotografía del estado actual del proyecto en el mundo real.

Instrucciones de análisis:
- IGNORA el ruido del entorno en la imagen de "Avance" (ej. herramientas, andamios, personas, iluminación del taller o fondo).
- ENFÓCATE estrictamente en la geometría, proporciones, ensamblaje, materiales visibles y detalles estructurales de la pieza o proyecto principal.
- COMPARA las similitudes y diferencias clave entre el "Render" y el "Avance".
- CALCULA un porcentaje de similitud del 0 al 100%. Considera que un 100% significa que la pieza del avance es idéntica en forma y características al render final.

Formato de Salida:
Debes responder ÚNICAMENTE con un objeto JSON con la siguiente estructura:
{
  "analisis_visual": "Descripción detallada de las similitudes y diferencias",
  "elementos_ignorados": "Lista de elementos del entorno ignorados",
  "calificacion_porcentaje": 85,
  "aprobado": true
}`;

      const renderPart = {
        inlineData: {
          data: renderImage.split(',')[1],
          mimeType: "image/jpeg"
        }
      };

      const avancePart = {
        inlineData: {
          data: avanceImage.split(',')[1],
          mimeType: "image/jpeg"
        }
      };

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [renderPart, avancePart, { text: prompt }] }],
        config: {
          responseMimeType: "application/json"
        }
      });

      const rawText = response.text || "{}";
      const data = JSON.parse(rawText);

      const newResult: AnalysisResult = {
        id: Math.random().toString(36).substring(2, 9).toUpperCase(),
        timestamp: Date.now(),
        render: renderImage,
        avance: avanceImage,
        ...data
      };

      setResult(newResult);
      const newHistory = [newResult, ...history].slice(0, 10);
      setHistory(newHistory);
      localStorage.setItem('visioncheck_history', JSON.stringify(newHistory));

    } catch (err) {
      console.error(err);
      setError("Error al analizar las imágenes. Por favor intenta de nuevo.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const downloadReport = () => {
    if (!result) return;
    const report = `
VISIONCHECK 3D - REPORTE DE INSPECCIÓN
ID: ${result.id}
Fecha: ${new Date(result.timestamp).toLocaleString()}
--------------------------------------------------
SIMILITUD: ${result.calificacion_porcentaje}%
ESTADO: ${result.aprobado ? 'APROBADO' : 'REQUIERE REVISIÓN'}

ANÁLISIS VISUAL:
${result.analisis_visual}

ELEMENTOS IGNORADOS:
${result.elementos_ignorados}
--------------------------------------------------
Generado por VisionCheck 3D AI
    `;
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Reporte_${result.id}.txt`;
    a.click();
  };

  const deleteFromHistory = (id: string) => {
    const newHistory = history.filter(item => item.id !== id);
    setHistory(newHistory);
    localStorage.setItem('visioncheck_history', JSON.stringify(newHistory));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('visioncheck_history');
  };

  useEffect(() => {
    const saved = localStorage.getItem('visioncheck_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isDraggingSlider) return;
    setIsPanning(true);
    setLastMousePos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDraggingSlider && comparisonRef.current) {
      const rect = comparisonRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      setSliderPos((x / rect.width) * 100);
      return;
    }

    if (!isPanning) return;
    
    const dx = e.clientX - lastMousePos.x;
    const dy = e.clientY - lastMousePos.y;
    setLastMousePos({ x: e.clientX, y: e.clientY });

    if (activeLayer === 'both' || activeLayer === 'render') {
      setRenderTransform(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
    }
    if (activeLayer === 'both' || activeLayer === 'avance') {
      setAvanceTransform(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
    setIsDraggingSlider(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!showComparison) return;
    const delta = e.deltaY > 0 ? -0.05 : 0.05;
    
    if (activeLayer === 'both' || activeLayer === 'render') {
      setRenderTransform(prev => ({ ...prev, scale: Math.min(Math.max(prev.scale + delta, 0.1), 10) }));
    }
    if (activeLayer === 'both' || activeLayer === 'avance') {
      setAvanceTransform(prev => ({ ...prev, scale: Math.min(Math.max(prev.scale + delta, 0.1), 10) }));
    }
  };

  const resetView = () => {
    setRenderTransform({ x: 0, y: 0, scale: 1 });
    setAvanceTransform({ x: 0, y: 0, scale: 1 });
    setSliderPos(50);
    setActiveLayer('both');
  };

  const resetLayer = (layer: 'render' | 'avance') => {
    if (layer === 'render') {
      setRenderTransform({ x: 0, y: 0, scale: 1 });
    } else {
      setAvanceTransform({ x: 0, y: 0, scale: 1 });
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 font-sans p-4 md:p-8 selection:bg-blue-500/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20 ring-1 ring-white/20">
              <ShieldCheck size={32} className="text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tighter text-white">VISIONCHECK <span className="text-blue-500">3D</span></h1>
              <p className="text-slate-400 font-medium text-sm">Auditoría de Calidad con IA de Próxima Generación</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-slate-900/80 border border-slate-800 rounded-xl flex items-center gap-3 backdrop-blur-md">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-widest text-slate-300">Sistema Operativo</span>
            </div>
          </div>
        </header>

        {/* Main Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          {/* Upload & Controls */}
          <div className="lg:col-span-8 space-y-8">
            <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-6 overflow-hidden relative group">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                <AlertCircle size={120} />
              </div>
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                <AlertCircle size={16} />
                Guía de Inspección
              </h3>
              <ul className="space-y-3 text-sm text-slate-300 relative z-10">
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-[10px] shrink-0 mt-0.5">1</div>
                  <p>Sube el <span className="text-white font-bold">Render</span> (diseño objetivo) y la foto del <span className="text-white font-bold">Avance</span> real.</p>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-[10px] shrink-0 mt-0.5">2</div>
                  <p>Usa el <span className="text-white font-bold">Visor de Alineación</span> para superponer y comparar visualmente.</p>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-[10px] shrink-0 mt-0.5">3</div>
                  <p>Haz clic en <span className="text-white font-bold">"Ejecutar Auditoría"</span> para obtener el análisis de la IA.</p>
                </li>
              </ul>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Render Upload */}
              <div className="space-y-2">
                <div 
                  onClick={() => renderInputRef.current?.click()}
                  className={`relative h-64 rounded-2xl border-2 border-dashed transition-all cursor-pointer group overflow-hidden ${
                    renderImage ? 'border-blue-500/50 bg-blue-500/5' : 'border-slate-800 hover:border-slate-700 bg-slate-900/30'
                  }`}
                >
                  <input type="file" ref={renderInputRef} onChange={(e) => handleImageUpload(e, 'render')} className="hidden" accept="image/*" />
                  {renderImage ? (
                    <img src={renderImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <ImageIcon className="text-slate-400" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-bold text-white">Subir Render</p>
                        <p className="text-xs text-slate-500 mt-1">Diseño Objetivo (3D/CAD)</p>
                      </div>
                    </div>
                  )}
                  <div className="absolute top-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-blue-400 border border-blue-500/30">
                    Objetivo
                  </div>
                </div>
                {renderImage && (
                  <button 
                    onClick={() => renderInputRef.current?.click()}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-widest text-slate-400 transition-colors"
                  >
                    Cambiar Render
                  </button>
                )}
              </div>

              {/* Avance Upload */}
              <div className="space-y-2">
                <div 
                  onClick={() => avanceInputRef.current?.click()}
                  className={`relative h-64 rounded-2xl border-2 border-dashed transition-all cursor-pointer group overflow-hidden ${
                    avanceImage ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-slate-800 hover:border-slate-700 bg-slate-900/30'
                  }`}
                >
                  <input type="file" ref={avanceInputRef} onChange={(e) => handleImageUpload(e, 'avance')} className="hidden" accept="image/*" />
                  {avanceImage ? (
                    <img src={avanceImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Upload className="text-slate-400" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-bold text-white">Subir Avance</p>
                        <p className="text-xs text-slate-500 mt-1">Fotografía del Estado Real</p>
                      </div>
                    </div>
                  )}
                  <div className="absolute top-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-emerald-400 border border-emerald-500/30">
                    Realidad
                  </div>
                </div>
                {avanceImage && (
                  <button 
                    onClick={() => avanceInputRef.current?.click()}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-widest text-slate-400 transition-colors"
                  >
                    Cambiar Avance
                  </button>
                )}
              </div>
            </div>

            {/* Comparison Slider */}
            {renderImage && avanceImage && (
              <div className="bg-slate-900/50 rounded-2xl border border-slate-800 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Layers size={16} />
                    Alineación de Capas
                  </h3>
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => setShowComparison(!showComparison)}
                      className="text-xs font-bold text-blue-400 hover:text-blue-300 uppercase tracking-widest"
                    >
                      {showComparison ? "Cerrar Visor" : "Abrir Visor de Alineación"}
                    </button>
                  </div>
                </div>
                
                {showComparison && (
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center gap-3 bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                      <div className="flex flex-col gap-1 mr-4">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Modo de Control</span>
                        <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
                          <button 
                            onClick={() => setActiveLayer('both')}
                            className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                              activeLayer === 'both' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-transparent text-slate-500 hover:text-slate-300'
                            }`}
                          >
                            <Layers size={14} />
                            Sincronizado
                          </button>
                          <button 
                            onClick={() => setActiveLayer('render')}
                            className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                              activeLayer === 'render' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'bg-transparent text-slate-500 hover:text-slate-300'
                            }`}
                          >
                            <ImageIcon size={14} />
                            Solo Render
                          </button>
                          <button 
                            onClick={() => setActiveLayer('avance')}
                            className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                              activeLayer === 'avance' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20' : 'bg-transparent text-slate-500 hover:text-slate-300'
                            }`}
                          >
                            <Upload size={14} />
                            Solo Realidad
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Acciones</span>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => resetLayer('render')}
                            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[10px] font-bold text-slate-400 transition-all flex items-center gap-2"
                            title="Resetear Render"
                          >
                            <History size={12} className="text-indigo-400" />
                            Reset Render
                          </button>
                          <button 
                            onClick={() => resetLayer('avance')}
                            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[10px] font-bold text-slate-400 transition-all flex items-center gap-2"
                            title="Resetear Realidad"
                          >
                            <History size={12} className="text-emerald-400" />
                            Reset Realidad
                          </button>
                          <button 
                            onClick={resetView}
                            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-[10px] font-bold text-slate-400 transition-all flex items-center gap-2"
                            title="Resetear Todo"
                          >
                            <Trash2 size={12} className="text-red-400" />
                            Limpiar Todo
                          </button>
                        </div>
                      </div>
                    </div>

                    <div 
                      ref={comparisonRef}
                      onMouseDown={handleMouseDown}
                      onMouseMove={handleMouseMove}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                      onWheel={handleWheel}
                      className={`relative h-[500px] rounded-xl overflow-hidden select-none border-2 transition-colors bg-black cursor-grab active:cursor-grabbing ${
                        activeLayer === 'render' ? 'border-indigo-500/50 shadow-[0_0_20px_rgba(99,102,241,0.1)]' : 
                        activeLayer === 'avance' ? 'border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.1)]' : 
                        'border-slate-700'
                      }`}
                    >
                      {/* Base Image (Avance) */}
                      <div 
                        className="absolute inset-0 w-full h-full transition-transform duration-75 ease-out"
                        style={{ 
                          transform: `translate(${avanceTransform.x}px, ${avanceTransform.y}px) scale(${avanceTransform.scale})`,
                          transformOrigin: 'center',
                          opacity: activeLayer === 'render' ? 0.3 : 1
                        }}
                      >
                        <img src={avanceImage} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      </div>

                      {/* Top Image (Render) with Clip */}
                      <div 
                        className="absolute inset-0 w-full h-full overflow-hidden transition-transform duration-75 ease-out"
                        style={{ 
                          clipPath: `inset(0 ${100 - sliderPos}% 0 0)`,
                          transform: `translate(${renderTransform.x}px, ${renderTransform.y}px) scale(${renderTransform.scale})`,
                          transformOrigin: 'center',
                          opacity: activeLayer === 'avance' ? 0.3 : 1
                        }}
                      >
                        <img src={renderImage} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      </div>

                      {/* UI Overlays */}
                      <div className="absolute top-4 left-4 flex gap-2 z-40">
                        <div className="px-2 py-1 bg-blue-600/80 rounded text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur-sm">Render</div>
                        <div className="px-2 py-1 bg-slate-800/80 rounded text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur-sm">Avance</div>
                      </div>

                      {/* Slider Control Handle (Custom) */}
                      <div 
                        className="absolute inset-y-0 w-1 bg-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.6)] z-50 cursor-ew-resize"
                        style={{ left: `${sliderPos}%` }}
                        onMouseDown={(e) => {
                          e.stopPropagation();
                          setIsDraggingSlider(true);
                        }}
                      >
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center shadow-2xl border-4 border-[#0f172a] hover:scale-110 transition-transform">
                          <Layers size={18} className="text-white" />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            <button 
              onClick={analyzeProgress}
              disabled={isAnalyzing || !renderImage || !avanceImage}
              className={`w-full py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-3 transition-all shadow-xl ${
                isAnalyzing || !renderImage || !avanceImage
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:scale-[1.02] active:scale-[0.98] shadow-blue-500/25'
              }`}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="animate-spin" />
                  Procesando Auditoría...
                </>
              ) : (
                <>
                  <ShieldCheck size={20} />
                  Ejecutar Auditoría de Calidad
                </>
              )}
            </button>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-4 space-y-6">
            <AnimatePresence mode="wait">
              {result ? (
                <motion.div 
                  key="result"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl sticky top-8"
                >
                  <div className={`p-8 text-center border-b border-slate-800 ${result.aprobado ? 'bg-emerald-500/10' : 'bg-amber-500/10'}`}>
                    <div className="flex justify-center mb-4">
                      {result.aprobado ? (
                        <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/20">
                          <CheckCircle2 size={40} className="text-white" />
                        </div>
                      ) : (
                        <div className="w-20 h-20 bg-amber-500 rounded-full flex items-center justify-center shadow-lg shadow-amber-500/20">
                          <XCircle size={40} className="text-white" />
                        </div>
                      )}
                    </div>
                    <h2 className="text-2xl font-black text-white mb-1">
                      {result.calificacion_porcentaje}% Similitud
                    </h2>
                    <p className={`text-xs font-black uppercase tracking-widest ${result.aprobado ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {result.aprobado ? 'Proyecto Aprobado' : 'Requiere Ajustes'}
                    </p>
                  </div>

                  <div className="p-8 space-y-8">
                    <div>
                      <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                        <ImageIcon size={12} />
                        Análisis Visual
                      </h4>
                      <p className="text-sm text-slate-300 leading-relaxed bg-slate-800/50 p-4 rounded-xl border border-slate-800">
                        {result.analisis_visual}
                      </p>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                        <ArrowRight size={12} />
                        Elementos Ignorados
                      </h4>
                      <p className="text-xs text-slate-400 italic leading-relaxed">
                        {result.elementos_ignorados}
                      </p>
                    </div>

                    <div className="pt-4 flex gap-3">
                      <button 
                        onClick={downloadReport}
                        className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-slate-700"
                      >
                        <Download size={14} />
                        Reporte
                      </button>
                      <button 
                        onClick={() => setResult(null)}
                        className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl transition-colors border border-slate-700"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full min-h-[400px] border-2 border-dashed border-slate-800 rounded-3xl flex flex-col items-center justify-center p-8 text-center"
                >
                  <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mb-6 border border-slate-800">
                    <Loader2 size={32} className="text-slate-700" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-400">Esperando Auditoría</h3>
                  <p className="text-sm text-slate-600 mt-2">Sube las imágenes y presiona ejecutar para ver los resultados aquí.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* History Section */}
        {history.length > 0 && (
          <section className="mt-20 pb-20">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center border border-slate-800">
                  <History size={20} className="text-blue-500" />
                </div>
                <h2 className="text-xl font-black text-white uppercase tracking-tight">Historial de Auditorías</h2>
              </div>
              <button 
                onClick={clearHistory}
                className="text-[10px] font-black text-slate-500 hover:text-red-400 uppercase tracking-widest transition-colors"
              >
                Borrar Todo
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {history.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-slate-900/50 border border-slate-800 rounded-2xl p-4 hover:border-slate-700 transition-all group"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-mono text-slate-500">ID: {item.id}</span>
                    <button 
                      onClick={() => deleteFromHistory(item.id)}
                      className="text-slate-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex gap-2 mb-4 h-20">
                    <img src={item.render} className="w-1/2 h-full object-cover rounded-lg border border-slate-800" referrerPolicy="no-referrer" />
                    <img src={item.avance} className="w-1/2 h-full object-cover rounded-lg border border-slate-800" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-lg font-black text-white">{item.calificacion_porcentaje}%</p>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest">{new Date(item.timestamp).toLocaleDateString()}</p>
                    </div>
                    <button 
                      onClick={() => setResult(item)}
                      className="px-4 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
                    >
                      Ver Detalles
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* Error Toast */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-red-500 text-white rounded-full shadow-2xl flex items-center gap-3 font-bold text-sm z-50"
            >
              <AlertCircle size={18} />
              {error}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
